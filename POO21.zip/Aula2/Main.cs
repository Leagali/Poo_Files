using System;

public class Program {

  public static void Main(string[] args) {
    Address a1 = new Address(
      "Avenida Comissário José Dantas de Melo", 
      21, 
      "Boa Vista II", 
      "Vila Velha", 
      "ES", 
      "29102-920"
    );

    Person p1 = new Person("John", "Doe", "ztejd@example.com", a1);
    try{
      p1.Age = 5;
      p1.Print();
    }
    catch(Exception e){
      Console.WriteLine(e.Message);
    }
  }
}