using System;

public abstract class Account
{
  public string AccountNumber {get;}
  public double Balance {get;protected set;}

  public Account(string accountNumber)
  {
    AccountNumber = accountNumber;
    Balance = 0.0;
  }

  public abstract void AccountType();
  public abstract void Withdraw(double amount);
  public abstract void FazerPix(Account account, double amount);

  public void Deposit(double amount)
  {
    if(amount > 0)
    {
      Balance += amount;
      Console.WriteLine($"Deposited {amount} to {AccountNumber}. New Balance: {Balance}");
    }else
    {
      throw new Exception("Invalid Operation.");
    }
  }

  public void InternTransfer(Account account, double amount)
  {
    if(Balance >= amount && amount > 0){
      Balance -= amount;
      account.Balance += amount;
      Console.WriteLine($"Transfer {amount} from {AccountNumber} to {account.AccountNumber}. New Balance: {Balance}");
    }
    else{
      throw new Exception("Invalid Operation.");
    }
  }

}