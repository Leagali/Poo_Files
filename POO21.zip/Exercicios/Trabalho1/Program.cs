using System;

class Program
{
    static void Main(string[] args)
    {
        AccountFactory currentFactory = new CurrentAccountFactory();
        var currentAccount = currentFactory.CreateAccount("12345-0");

        try
        {
            currentAccount.Deposit(500); 
            currentAccount.Withdraw(100); 
            currentAccount.Withdraw(50);  

            var anotherCurrentAccount = currentFactory.CreateAccount("54321-0");
            currentAccount.InternTransfer(anotherCurrentAccount, 200);

            Console.WriteLine($"Current Account Balance: {currentAccount.Balance}");
            Console.WriteLine($"Another Current Account Balance: {anotherCurrentAccount.Balance}");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
          AccountFactory savingsFactory = new SavingsAccountFactory();
          var savingsAccount = savingsFactory.CreateAccount("12504-0");


        savingsAccount.Deposit(200);

        try
        {
            savingsAccount.Withdraw(30); 
            savingsAccount.Withdraw(30); 
            savingsAccount.Withdraw(30); 
            savingsAccount.Withdraw(30);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}