public class SavingsAccountFactory : AccountFactory
{
  public override Account CreateAccount(string accountNumber)
  {
    return new SavingsAccount(accountNumber);
  }
}