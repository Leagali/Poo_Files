using System;

public class CurrentAccount : Account
{
  public CurrentAccount(string accountNumber) : base(accountNumber){}

  public override void AccountType(){
    Console.WriteLine("This is a Current Account.");
  }

  public override void Withdraw(double amount)
  {
    if(Balance >= amount && amount > 0)
    {
      Balance -= amount;
      Console.WriteLine($"Withdraw {amount} from {AccountNumber}. New Balance: {Balance}");
    }else
    {
      throw new Exception("Invalid Operation.");
    }
  }

  public override void FazerPix(Account account, double amount)
  {
    if(Balance >= amount && amount > 0){
      Withdraw(amount);
      account.Deposit(amount);
    }
    else{
      throw new Exception("Invalid Operation.");
    }
  }
}