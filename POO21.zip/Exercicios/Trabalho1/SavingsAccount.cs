using System;

public class SavingsAccount : Account
{
  private int withdrawCount;
  private const double SERVICE = 1.00;
  
  public SavingsAccount(string accountNumber) : base(accountNumber){
    withdrawCount = 0;
  }

  public override void AccountType(){
    Console.WriteLine("This is a Savings Account.");
  }

  public void Render(double interestRate){
    Balance += Balance * interestRate;
    Console.WriteLine(Balance);
  }

  public override void Withdraw(double amount)
  {
      if (amount <= 0)
      {
          throw new Exception("Invalid Operation.");
      }

      if (withdrawCount >= 3)
      {
          amount += SERVICE;
      }

      if (Balance >= amount)
      {
          Balance -= amount;
          withdrawCount++;
          Console.WriteLine($"Withdraw {amount} from {AccountNumber}. New Balance: {Balance}");
      }
      else
      {
          throw new Exception("Invalid Operation.");
      }
  }

  public override void FazerPix(Account account, double amount)
  {
      throw new Exception("FazerPix not allowed for Savings Account.");
  }

}