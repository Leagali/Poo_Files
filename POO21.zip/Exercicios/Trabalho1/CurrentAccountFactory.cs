public class CurrentAccountFactory : AccountFactory
{
  public override Account CreateAccount(string accountNumber)
  {
    return new CurrentAccount(accountNumber);
  }
}