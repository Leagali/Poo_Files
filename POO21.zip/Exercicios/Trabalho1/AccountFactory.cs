public abstract class AccountFactory
{
  public abstract Account CreateAccount(string accountNumber);


  public string OpenAccount(string accountNumber)
  {
    var account = CreateAccount(accountNumber);
    account.AccountType();
    return accountNumber;
  }
}