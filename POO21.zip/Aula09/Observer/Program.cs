using System;
using System.Collections.Generic;

public class Program
{
    private static List<Station> stations = new List<Station>();
    private static List<Monitor> monitors = new List<Monitor>();

    public static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("\nMenu: ");
            Console.WriteLine("0 - Sair");
            Console.WriteLine("1 - Criar Nova Estação");
            Console.WriteLine("2 - Atualizar Estação");
            Console.WriteLine("3 - Remover Estação");
            Console.WriteLine("4 - Criar Monitor");
            Console.WriteLine("5 - Adicionar Monitor a uma Estação");
            Console.WriteLine("Escolha uma opção: ");
            string r = Console.ReadLine();

            if (r == "0")
            {
                break;
            }
            else if (r == "1")
            {
                Station station = new Station();
                stations.Add(station);
                Console.WriteLine("Nova estação criada.");
            }
            else if (r == "2")
            {
                Console.WriteLine("Digite o índice da estação para atualizar (começando em 0): ");
                int index = int.Parse(Console.ReadLine());

                if (index >= 0 && index < stations.Count)
                {
                    Console.WriteLine("Digite a nova temperatura: ");
                    float temp = float.Parse(Console.ReadLine());
                    stations[index].UpdateStation(temp);
                    Console.WriteLine("Estação atualizada.");
                }
                else
                {
                    Console.WriteLine("Índice inválido!");
                }
            }
            else if (r == "3")
            {
                Console.WriteLine("Digite o índice da estação para remover (começando em 0): ");
                int index = int.Parse(Console.ReadLine());

                if (index >= 0 && index < stations.Count)
                {
                    stations.RemoveAt(index);
                    Console.WriteLine("Estação removida.");
                }
                else
                {
                    Console.WriteLine("Índice inválido!");
                }
            }
            else if (r == "4")
            {
                Monitor monitor = new Monitor();
                monitors.Add(monitor);
                Console.WriteLine("Novo monitor criado.");
            }
            else if (r == "5")
            {
                Console.WriteLine("Digite o índice da estação (começando em 0): ");
                int stationIndex = int.Parse(Console.ReadLine());

                Console.WriteLine("Digite o índice do monitor (começando em 0): ");
                int monitorIndex = int.Parse(Console.ReadLine());

                if (stationIndex >= 0 && stationIndex < stations.Count && monitorIndex >= 0 && monitorIndex < monitors.Count)
                {
                    stations[stationIndex].AddObserver(monitors[monitorIndex]);
                    Console.WriteLine("Monitor adicionado à estação.");
                }
                else
                {
                    Console.WriteLine("Índice inválido!");
                }
            }
            else
            {
                Console.WriteLine("Opção inválida!");
            }
        }
    }
}
