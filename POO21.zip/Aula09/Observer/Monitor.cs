using System;
using System.Collections.Generic;

public class Monitor : IObserver
{
  public void Update(float temp){
    Console.WriteLine("The temperature is now: " + temp + "°C");
  }
}
