using System;
using System.Collections.Generic;

public class Station : ISubject
{
  private List<IObserver> _observers;
  private float _temperature;
  private string uf;

  public Station(){
    _observers = new List<IObserver>();
  }

  public void AddObserver(IObserver observer){
    _observers.Add(observer);
  }

  public void RemoveObserver(IObserver observer){
    _observers.Remove(observer);
  }

  public void NotifyObservers(){
    foreach(var observer in _observers){
      observer.Update(_temperature);
    }
  }

  public void SetTemperature(float temperature){
    _temperature = temperature;
    NotifyObservers();
  }

  public void SetUf(string uf){
    this.uf = uf;
    NotifyObservers();
  }

  public void UpdateStation(float newTemperature)
  {
      SetTemperature(newTemperature);
  }
  
}