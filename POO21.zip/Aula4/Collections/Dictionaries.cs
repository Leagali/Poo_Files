/*
  Collections:
   - Dictionaries(Dictionary<TKey, TValue>): Tamanho fixo, não ordenado, não indexado, não mútavel e permite duplicatas. ()
*/

using System;
using System.Collections.Generic;

class Program{
  static void Main(string[] args){
    Dictionary<string, int> idades = new Dictionary<string, int>{

      {"Carlos", 30},
      {"Joao", 22},
      {"Clara", 18},
    };

    idades.Add("Alice", 25);
    idades.Add("Bob", 30);
    idades.Add("Jhon", 28);

    Console.WriteLine("Clara tem " + idades["Clara"] + " anos.");

    if(idades.ContainsKey("Bob")){
      Console.WriteLine("Eu sei a idade de Bob.");
      }
      else{
        Console.WriteLine("Eu não sei a idade de Bob.");
      }

    idades["Clara"] = 19;

    Console.WriteLine("Clara tem " + idades["Clara"] + " anos.");

    idades.Remove("Clara");

    if(idades.ContainsKey("Clara")){
      Console.WriteLine("Eu sei a idade de Clara.");
    }
    else{
      Console.WriteLine("Eu não sei a idade de Clara.");
    }

    foreach (KeyValuePair<string, int> pair in idades){
      Console.WriteLine(pair.Key + " tem " + pair.Value + " anos.");  
    }

    foreach (string nome in idades.Keys){
      Console.WriteLine(nome + " tem " + idades[nome] + " anos.");
    }

    Console.WriteLine("Quantidade de pessoas: " + idades.Count);
  
    idades.Clear();

    Console.WriteLine("Quantidade de pessoas: " + idades.Count);
  }
}