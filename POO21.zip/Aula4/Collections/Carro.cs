//Tentativa

using System;

class Carro{
    public double posicao = 0;

    public double DeslocarMRU(double posicao, double velocidade, double tempo){
        return posicao + (velocidade * tempo);
    }

    public double DeslocarMRUV(double posicao, double velocidadeInicial, double aceleracao, double tempo){
        return posicao + (velocidadeInicial * tempo) + (aceleracao * (tempo * tempo) / 2);
    }
  
  }

class Program{
  static void Main(string[] args){
    Carro c = new Carro();

    Console.WriteLine(c.DeslocarMRU(0, 10, 5));
    Console.WriteLine(c.DeslocarMRUV(0, 10, 2, 5));

  }
}