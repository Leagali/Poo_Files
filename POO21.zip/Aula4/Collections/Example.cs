using System;

class Calculator{

  public int Add(int a, int b){
    return a + b;
  }

  public int Add(int a, int b, int c){
    return a + b + c;
  }

  public double Add(double a, double b){
    return a + b;
  }
}

class Program{
  static void Main(string[] args){
    Calculator c = new Calculator();

    int sum1 = c.Add(1, 2);
    int sum2 = c.Add(1, 2, 3);
    double sum3 = c.Add(1.5, 2.5);

    Console.WriteLine(sum1);
    Console.WriteLine(sum2);
    Console.WriteLine(sum3);
    
  }
}