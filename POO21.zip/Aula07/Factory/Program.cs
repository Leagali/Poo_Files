using System;

public class Program
{
  public static void Main(string[] args)
  {
    Transportadora tc = new TransCam();
    tc.realizarEntrega();

    Transportadora tv = new TransVan();
    tv.realizarEntrega();
  }
}