using System;

public class TransVan : Transportadora
{
    public override ITransporte criarTransporte()
    {
        return new Van();
    }
}