using System;

public abstract class Transportadora
{
    public abstract ITransporte criarTransporte();

    public void realizarEntrega()
    {
        ITransporte transporte = criarTransporte();
        transporte.Entregar();
    } 
}