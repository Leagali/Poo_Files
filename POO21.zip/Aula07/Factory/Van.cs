using System;

public class Van : ITransporte
{
  public void Entregar()
  {
    Console.WriteLine("Entregando via van");
  }
}