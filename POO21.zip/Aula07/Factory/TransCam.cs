using System;

public class TransCam : Transportadora
{
    public override ITransporte criarTransporte()
    {
        return new Caminhao();
    }
}