using System;

public interface ITransporte
{
    void Entregar();  
}