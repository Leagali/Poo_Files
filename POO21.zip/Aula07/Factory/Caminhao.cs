using System;

public class Caminhao : ITransporte
{
  public void Entregar()
  {
    Console.WriteLine("Entregando via caminhão");
  }
}