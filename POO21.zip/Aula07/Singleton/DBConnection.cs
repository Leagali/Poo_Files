using System;

public class DBConnection
{
  private static DBConnection _instance;

  private DBConnection(){
    Console.WriteLine("Conexão com o banco de dados criada");
  }

  public static DBConnection Instance
  {
    get
    {
      if(_instance == null)
      {
        _instance = new DBConnection();
      }
      return _instance;
    }
  }

  public void ExecuteCommand(string sql)
  {
    Console.WriteLine("Executando comando: " + sql);
  }
}

public class Program
{
  public static void Main()
  {
    DBConnection c1 = DBConnection.Instance;
    c1.ExecuteCommand("SELECT * FROM xpto");

    DBConnection c2 = DBConnection.Instance;
    c2.ExecuteCommand("Update xpto SET name='Jose' WHERE id=12");

    if(c1 == c2)
    {
      Console.WriteLine("As duas conexões são a mesma");
    }
  }
}