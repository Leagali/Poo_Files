using System;
using System.Collections.Generic;

public interface ICafe
{
  string Descricao();
  double Custo();
}