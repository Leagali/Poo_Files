using System;
using System.Collections.Generic;

public class Program
{
  public static void Main(string[] args)
  {
    ICafe cafeSimples = new CafeSimples();

    Console.WriteLine(cafeSimples.Descricao() + " R$: " + cafeSimples.Custo());

    ICafe cafeComLeite = new LeiteDecorator(cafeSimples);

    Console.WriteLine(cafeComLeite.Descricao() + " R$: " + cafeComLeite.Custo());

    ICafe cafeComChocolate = new ChocolateDecorator(cafeComLeite);

    Console.WriteLine(cafeComChocolate.Descricao() + " R$: " + cafeComChocolate.Custo());
  }
}