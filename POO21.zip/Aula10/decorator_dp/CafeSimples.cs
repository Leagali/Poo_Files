using System;
using System.Collections.Generic;

public class CafeSimples : ICafe
{
    public string Descricao()
    {
      return "Café Simples";
    }

    public double Custo()
    {
      return 2.00;    
    }
}