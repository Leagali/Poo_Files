using System;

namespace PolimorfismoExemplo{
  public class Dog : Animal{
    public override string makeSound(){
      return "au au";
    }
  }
}