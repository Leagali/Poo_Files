using System;

namespace PolimorfismoExemplo{
  public class Wolf : Animal{
    public override string makeSound(){
      return "Alpha ";
    }
  }
}