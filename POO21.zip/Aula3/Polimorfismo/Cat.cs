using System;

namespace PolimorfismoExemplo{
  public class Cat : Animal{
    public override string makeSound(){
      return "miau miau";
    }
  }
}