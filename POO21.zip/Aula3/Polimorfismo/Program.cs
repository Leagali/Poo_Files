using System;
using PolimorfismoExemplo;

class Program{
  static void Main(string[] args){

    Animal a1 = new Wolf();

    Console.WriteLine(a1.makeSound());
    
    Animal[] animals = new Animal[]{ new Dog(), new Cat(), new Wolf()};

    foreach (Animal animal in animals){
      Console.WriteLine(animal.makeSound());
    }
  }
}
