using System;

namespace PolimorfismoExemplo{
  public abstract class Animal{
    public abstract string makeSound();
  }  
}