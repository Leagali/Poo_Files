using System;
using System.Collections.Generic;

class Program{
  public static void Main(string[] args){
    /*
      Collections:
        - Lists(List<T>): Ordenadas, indexadas, mútaveis e permite duplicatas.
    */
    List<string> fruits = new List<string> { "Apple", "Banana", "Orange", "Lemon" };
    fruits.Add("Pineapple");

    fruits.AddRange(new string[] { "Mango", "Grape" });

    fruits.Remove("Pineapple");

    fruits.Insert(1, "Pineapple");

    Console.WriteLine(fruits[1]);
    Console.WriteLine(fruits[4]);

    Console.WriteLine("Usando for:");
    for (int i = 0; i < fruits.Count; i++){
      Console.WriteLine(i + " - " + fruits[i]);
    }

    fruits.Sort();

    foreach (string fruit in fruits){
      Console.WriteLine(fruit);
    }

    Console.WriteLine("Quantidade: " + fruits.Count);
  }
}