using System;

public class Esfera : FigGeo{

  public double pi = 3.14;
  public double raio = 2;

  public override string CalcularPerimetro(){
    return "Não é possível";
  }

  public override string CalcularArea(){
    return "A area da esfera é: " + 4 * pi * raio * raio;
  }

  public override string CalcularVolume(){
    return "O volume da esfera é: " + (4 * pi * raio * raio * raio) / 3;
  }
}

public class Cubo : FigGeo{

  public double lado = 2;
  
  public override string CalcularPerimetro(){
      return "Não é possível";
    }

  public override string CalcularArea(){
      return "A area do cubo é: " + 6 * lado * lado;
    }

   public override string CalcularVolume(){
      return "O volume do cubo é: " + lado * lado * lado;
   }

}

public class Cilindro : FigGeo{

  public double pi = 3.14;
  public double raio = 3;
  public double altura = 4;

  public override string CalcularPerimetro(){
    return "Não é possível";
  }

  public override string CalcularArea(){
    return "A area do cilindro é: " + (2 * pi * raio * altura) + (2 * pi * raio * raio);
  }

  public override string CalcularVolume(){
    return "O volume do cilindro é: " + pi * raio * raio * altura;
  }
}

public class Cone : FigGeo{
  
  public double pi = 3.14;
  public double raio = 3;
  public double altura = 4;

  public override string CalcularPerimetro(){
    return "Não é possível";
  }

  public override string CalcularArea(){
    double geratriz = Math.Sqrt(raio * raio + altura * altura);

    double areaTotal = pi * raio * (raio + geratriz);

    return "A area do cone é: " + areaTotal;
  }

  public override string CalcularVolume(){
    return "O volume do cone é: " + pi * raio * raio * altura / 3;
  }
}