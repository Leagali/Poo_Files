using System;

public abstract class FigGeo{

  public abstract string CalcularPerimetro();

  public abstract string CalcularArea();

  public abstract string CalcularVolume();
}
