using System;

public class Program
{
    public static void Main()
    {
        Circulo circulo = new Circulo();
        Quadrado quadrado = new Quadrado();
        Retangulo retangulo = new Retangulo();
        Triangulo triangulo = new Triangulo();
        Esfera esfera = new Esfera();
        Cubo cubo = new Cubo();
        Cilindro cilindro = new Cilindro();
        Cone cone = new Cone();

        
        Console.WriteLine(circulo.CalcularPerimetro());
        Console.WriteLine(circulo.CalcularArea() + "\n");

        Console.WriteLine(quadrado.CalcularPerimetro());
        Console.WriteLine(quadrado.CalcularArea()+ "\n");

        Console.WriteLine(retangulo.CalcularPerimetro());
        Console.WriteLine(retangulo.CalcularArea()+ "\n");

        Console.WriteLine(triangulo.CalcularPerimetro());
        Console.WriteLine(triangulo.CalcularArea()+ "\n");
 
        Console.WriteLine(esfera.CalcularArea()); 
        Console.WriteLine(esfera.CalcularVolume()+ "\n");
 
        Console.WriteLine(cubo.CalcularArea()); 
        Console.WriteLine(cubo.CalcularVolume()+ "\n");

        Console.WriteLine(cilindro.CalcularArea()); 
        Console.WriteLine(cilindro.CalcularVolume()+ "\n");

        Console.WriteLine(cone.CalcularArea());
        Console.WriteLine(cone.CalcularVolume());
    }
}