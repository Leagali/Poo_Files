using System;

  public class Circulo : FigGeo{

    public double pi = 3.14;
    public double raio = 3;
    
    public override string CalcularPerimetro(){
      return "O perimetro do circulo é: " + 2 * pi * raio;
    }

    public override string CalcularArea(){
      return "A area do circulo é: " + pi * raio * raio;
    }
    
    public override string CalcularVolume()
    {
        return "Não é possível calcular o volume de um círculo.";
    }
  }

  public class Quadrado : FigGeo{

    public double lado = 2;

    public override string CalcularPerimetro(){
      return "O perimetro do quadrado é: " + 4 * lado;
    }

    public override string CalcularArea(){
      return "A area do quadrado é: " + lado * lado;
    }

    public override string CalcularVolume()
    {
        return "Não é possível calcular o volume de um quadrado.";
    }
  }

  public class Retangulo : FigGeo{

    public double lado1 = 2;
    public double lado2 = 3;

    public override string CalcularPerimetro(){
      return "O perimetro do retangulo é: " + 2 * (lado1 + lado2);
    }

    public override string CalcularArea(){
      return "A area do retangulo é: " + lado1 * lado2;
    }

    public override string CalcularVolume()
    {
        return "Não é possível calcular o volume de um retângulo.";
    }
  }

  public class Triangulo : FigGeo{
    
    public double lado1 = 2;
    public double lado2 = 3;
    public double lado3 = 4;

    public override string CalcularPerimetro(){
      return "O perimetro do triangulo é: " + (lado1 + lado2 + lado3);
    }

    public override string CalcularArea()
    {
        double s = (lado1 + lado2 + lado3) / 2;
        double area = Math.Sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
        return "A área do triângulo é: " + area;
    }

    public override string CalcularVolume()
    {
        return "Não é possível calcular o volume de um triângulo.";
    }
  }
